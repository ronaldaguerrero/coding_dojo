let express = require('express');
let app = express();

app.use(express.static( __dirname + '/public/dist/public' ));

// app.get('/', function(req,res){
// 	res.json({'hello':'hello'});
// })

app.listen(8000, function() {
  console.log("Listening on port 8000")
})