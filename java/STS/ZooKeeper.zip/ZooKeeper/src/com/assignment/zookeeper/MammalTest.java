package com.assignment.zookeeper;

public class MammalTest {

	public static void main(String[] args) {
		Mammal type = new Mammal();
		type.displayEnergy();
		
	}
}
