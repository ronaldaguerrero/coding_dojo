package com.assignment.zookeeper2;

public class BatTest {

	public static void main(String[] args) {
		Bat bType = new Bat();
		bType.attackTown();
		bType.attackTown();
		bType.attackTown();
		bType.eatHumans();
		bType.eatHumans();
		bType.fly();
		bType.fly();
	}

}
