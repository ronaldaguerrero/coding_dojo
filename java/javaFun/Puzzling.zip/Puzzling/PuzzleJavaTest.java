import java.util.ArrayList;
import java.util.List;

public class PuzzleJavaTest{
	public static void main(String[] args){
		// int[] array = {3,5,1,2,7,9,8,13,25,32};
		// PuzzleJava.printSum(array);
		// ArrayList<String> names = new ArrayList<String>();
		// names.add("Nancy");
		// names.add("Luis");
		// names.add("Freddie");
		// names.add("Frankie");
		// names.add("Patrick");
		// PuzzleJava.shuffle(names);
		// PuzzleJava.alphabet();
		// PuzzleJava.randomOne();
		// PuzzleJava.randomTwo();
		// PuzzleJava.randomString(5);
		PuzzleJava.randomArrays(5);

	}
}