package com.codingdojo.ninjagold;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NinjagoldApplication {

	public static void main(String[] args) {
		SpringApplication.run(NinjagoldApplication.class, args);
	}

}

