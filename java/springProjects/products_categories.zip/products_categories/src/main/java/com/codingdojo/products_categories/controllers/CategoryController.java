package com.codingdojo.products_categories.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.codingdojo.products_categories.models.Category;
import com.codingdojo.products_categories.models.Product;
import com.codingdojo.products_categories.services.CategoryService;
import com.codingdojo.products_categories.services.ProductService;

@Controller
public class CategoryController {
	private final ProductService prodService;
	private final CategoryService catService;
	
	public CategoryController(ProductService prodService, CategoryService catService) {
		this.catService = catService;
		this.prodService = prodService;
	}
	
	@RequestMapping("categories/new")
	public String index(@ModelAttribute("catObj") Category cat) {
		return "pro_cat/category.jsp";
	}
	
	@PostMapping(value="create/cat")
	public String newCat(@ModelAttribute("catObj") Category cat, Model model) {
		catService.createCat(cat);
		return "redirect:/categories/new";
	}
	
	@RequestMapping("categories/{id}")
	public String show(@PathVariable("id") long id, Model model) {
		Category cat = catService.findCat(id);
		model.addAttribute("cat", cat);
		List<Product> prod = prodService.allExcept(id);
		model.addAttribute("prod", prod);
		return "/pro_cat/showC.jsp";
	}
	
	@PostMapping(value="linkP/{id}")
	public String linkProd(@RequestParam("prodChoice") long p, @PathVariable("id") long catId) {
		Category cat = catService.findCat(catId);
		Product prod = prodService.findProd(p);
		List<Product> products = cat.getProducts();
		products.add(prod);
		catService.createCat(cat);
		return "redirect:/categories/{id}";
	}
}
